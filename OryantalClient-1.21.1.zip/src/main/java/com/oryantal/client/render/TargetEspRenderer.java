package com.oryantal.client.render;

import com.oryantal.client.module.AuraModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;

public class TargetEspRenderer {
    public static void renderTargetEffects() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;

        LivingEntity target = AuraModule.getTarget();
        if (target == null) return;

        AuraModule.EspMode mode = AuraModule.getEspMode();
        long time = System.currentTimeMillis();

        if (mode == AuraModule.EspMode.NURSULTAN) {
            for (int i = 0; i < 3; i++) {
                double angle = (time / 300.0) + (i * (Math.PI * 2 / 3));
                double x = target.getX() + Math.cos(angle) * 1.2;
                double z = target.getZ() + Math.sin(angle) * 1.2;
                double y = target.getY() + ((Math.sin(time / 200.0 + i) + 1) * 0.5);
            }
        } else if (mode == AuraModule.EspMode.ORYANTAL) {
            for (int i = 0; i < 3; i++) {
                double angle = -(time / 400.0) + (i * (Math.PI * 2 / 3));
                double x = target.getX() + Math.sin(angle) * 1.5;
                double z = target.getZ() + Math.cos(angle) * 1.5;
                double y = target.getY() + target.getHeight() / 2;
            }
        }
    }
}
