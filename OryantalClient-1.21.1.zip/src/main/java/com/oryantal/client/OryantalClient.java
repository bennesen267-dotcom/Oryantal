package com.oryantal.client;

import com.oryantal.client.module.AuraModule;
import com.oryantal.client.ui.ClickGuiScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OryantalClient implements ClientModInitializer {
    public static final String MOD_ID = "oryantalclient";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static KeyBinding guiKeyBinding;

    @Override
    public void onInitializeClient() {
        LOGGER.info("Oryantal Client 1.21.1 başlatılıyor...");

        // Sağ Shift (RIGHT_SHIFT) ile menüyü açma tuşu
        guiKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.oryantalclient.gui",
                InputUtil.Type.KEY_SYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.oryantalclient.main"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            // Sağ Shift basıldığında ClickGUI açılır
            while (guiKeyBinding.wasPressed()) {
                client.setScreen(new ClickGuiScreen());
            }

            // Aura modülü aktifse her tick çalışır
            AuraModule.onTick(client);
        });
    }
}
