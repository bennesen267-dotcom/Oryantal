package com.oryantal.client.ui;

import com.oryantal.client.module.AuraModule;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class ClickGuiScreen extends Screen {
    private String currentCategory = "Combat";

    public ClickGuiScreen() {
        super(Text.literal("Oryantal Client - ClickGUI"));
    }

    @Override
    protected void init() {
        super.init();
        int startX = this.width / 2 - 160;
        int startY = 40;

        // Kategori Butonları
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Combat"), b -> currentCategory = "Combat")
                .dimensions(startX, startY, 70, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Movement"), b -> currentCategory = "Movement")
                .dimensions(startX + 75, startY, 70, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Render"), b -> currentCategory = "Render")
                .dimensions(startX + 150, startY, 70, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Misc"), b -> currentCategory = "Misc")
                .dimensions(startX + 225, startY, 70, 20).build());

        // Combat İçeriği (Aura Ayarları)
        if (currentCategory.equals("Combat")) {
            // Aura Açma / Kapatma
            this.addDrawableChild(ButtonWidget.builder(
                    Text.literal("Aura: " + (AuraModule.isEnabled() ? "§aAçık" : "§cKapalı")),
                    b -> {
                        AuraModule.setEnabled(!AuraModule.isEnabled());
                        b.setMessage(Text.literal("Aura: " + (AuraModule.isEnabled() ? "§aAçık" : "§cKapalı")));
                    }
            ).dimensions(startX, startY + 40, 200, 20).build());

            // Vuruş Mesafesi (Attack Range)
            this.addDrawableChild(ButtonWidget.builder(
                    Text.literal("Attack Range: " + String.format("%.1f", AuraModule.getAttackRange())),
                    b -> {
                        double next = AuraModule.getAttackRange() + 1.0;
                        if (next > 8.0) next = 3.0;
                        AuraModule.setAttackRange(next);
                        b.setMessage(Text.literal("Attack Range: " + String.format("%.1f", AuraModule.getAttackRange())));
                    }
            ).dimensions(startX, startY + 70, 200, 20).build());

            // Algılama Mesafesi (Detection Range)
            this.addDrawableChild(ButtonWidget.builder(
                    Text.literal("Detect Range: " + String.format("%.1f", AuraModule.getDetectionRange())),
                    b -> {
                        double next = AuraModule.getDetectionRange() + 5.0;
                        if (next > 30.0) next = 5.0;
                        AuraModule.setDetectionRange(next);
                        b.setMessage(Text.literal("Detect Range: " + String.format("%.1f", AuraModule.getDetectionRange())));
                    }
            ).dimensions(startX, startY + 100, 200, 20).build());

            // Rotations Seçimi
            this.addDrawableChild(ButtonWidget.builder(
                    Text.literal("Rotation: " + AuraModule.getRotationMode().name()),
                    b -> {
                        AuraModule.RotationMode next = switch (AuraModule.getRotationMode()) {
                            case GRIM -> AuraModule.RotationMode.VULCAN;
                            case VULCAN -> AuraModule.RotationMode.MATRIX;
                            case MATRIX -> AuraModule.RotationMode.SPOOKYTIME;
                            case SPOOKYTIME -> AuraModule.RotationMode.FUNTIME;
                            case FUNTIME -> AuraModule.RotationMode.GRIM;
                        };
                        AuraModule.setRotationMode(next);
                        b.setMessage(Text.literal("Rotation: " + next.name()));
                    }
            ).dimensions(startX, startY + 130, 200, 20).build());

            // Client Look Toggle
            this.addDrawableChild(ButtonWidget.builder(
                    Text.literal("Client Look: " + (AuraModule.isClientLook() ? "§aAktif" : "§cKapalı")),
                    b -> {
                        AuraModule.setClientLook(!AuraModule.isClientLook());
                        b.setMessage(Text.literal("Client Look: " + (AuraModule.isClientLook() ? "§aAktif" : "§cKapalı")));
                    }
            ).dimensions(startX, startY + 160, 200, 20).build());

            // Target ESP Mode (Nursultan vs Oryantal)
            this.addDrawableChild(ButtonWidget.builder(
                    Text.literal("Target ESP: " + AuraModule.getEspMode().name()),
                    b -> {
                        AuraModule.EspMode next = AuraModule.getEspMode() == AuraModule.EspMode.ORYANTAL ? AuraModule.EspMode.NURSULTAN : AuraModule.EspMode.ORYANTAL;
                        AuraModule.setEspMode(next);
                        b.setMessage(Text.literal("Target ESP: " + next.name()));
                    }
            ).dimensions(startX, startY + 190, 200, 20).build());
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 15, 0xFF55FF);
        context.drawCenteredTextWithShadow(this.textRenderer, "Kategori: " + currentCategory, this.width / 2, 70, 0xAAAAAA);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
