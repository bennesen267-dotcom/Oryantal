package com.oryantal.client.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;

import java.util.List;

public class AuraModule {
    private static boolean enabled = false;
    
    // Ayarlar (Sliders / Options)
    private static double attackRange = 3.0;     // 3.0 - 8.0 blok
    private static double detectionRange = 10.0;  // 5.0 - 30.0 blok
    private static RotationMode rotationMode = RotationMode.GRIM;
    private static boolean clientLook = false;    // Kamerayı kitleme
    private static EspMode espMode = EspMode.ORYANTAL; // NURSULTAN veya ORYANTAL
    
    private static LivingEntity target = null;

    public enum RotationMode {
        SPOOKYTIME, FUNTIME, MATRIX, GRIM, VULCAN
    }

    public enum EspMode {
        NURSULTAN, ORYANTAL
    }

    public static boolean isEnabled() { return enabled; }
    public static void setEnabled(boolean state) { enabled = state; }

    public static double getAttackRange() { return attackRange; }
    public static void setAttackRange(double val) { attackRange = Math.max(3.0, Math.min(8.0, val)); }

    public static double getDetectionRange() { return detectionRange; }
    public static void setDetectionRange(double val) { detectionRange = Math.max(5.0, Math.min(30.0, val)); }

    public static RotationMode getRotationMode() { return rotationMode; }
    public static void setRotationMode(RotationMode mode) { rotationMode = mode; }

    public static boolean isClientLook() { return clientLook; }
    public static void setClientLook(boolean val) { clientLook = val; }

    public static EspMode getEspMode() { return espMode; }
    public static void setEspMode(EspMode mode) { espMode = mode; }

    public static LivingEntity getTarget() { return target; }

    public static void onTick(MinecraftClient client) {
        if (!enabled || client.player == null || client.world == null) {
            target = null;
            return;
        }

        // Hedef Taraması (Detection Range)
        Box searchBox = client.player.getBoundingBox().expand(detectionRange);
        List<Entity> entities = client.world.getOtherEntities(
                client.player,
                searchBox,
                e -> e instanceof LivingEntity && e.isAlive() && e != client.player
        );

        LivingEntity bestTarget = null;
        double minDistance = detectionRange + 1;

        for (Entity e : entities) {
            double dist = client.player.distanceTo(e);
            if (dist <= detectionRange && dist < minDistance) {
                minDistance = dist;
                bestTarget = (LivingEntity) e;
            }
        }

        target = bestTarget;

        if (target != null) {
            // Rotations & Client Look Mantığı
            double dX = target.getX() - client.player.getX();
            double dZ = target.getZ() - client.player.getZ();
            double dY = (target.getY() + target.getEyeHeight(target.getPose())) - (client.player.getY() + client.player.getEyeHeight(client.player.getPose()));
            double distXZ = Math.sqrt(dX * dX + dZ * dZ);

            float yaw = (float) (Math.toDegrees(Math.atan2(dZ, dX)) - 90.0F);
            float pitch = (float) (-Math.toDegrees(Math.atan2(dY, distXZ)));

            // Seçilen Rotasyon Moduna Göre Farklı Davranış Simülasyonu
            switch (rotationMode) {
                case SPOOKYTIME, FUNTIME, MATRIX, GRIM, VULCAN:
                    if (clientLook) {
                        client.player.setYaw(yaw);
                        client.player.setPitch(pitch);
                    }
                    break;
            }

            // Vuruş Mesafesi (Attack Range: 3-8 blok)
            if (client.player.distanceTo(target) <= attackRange) {
                client.interactionManager.attackEntity(client.player, target);
                client.player.swingHand(Hand.MAIN_HAND);
            }
        }
    }
}
